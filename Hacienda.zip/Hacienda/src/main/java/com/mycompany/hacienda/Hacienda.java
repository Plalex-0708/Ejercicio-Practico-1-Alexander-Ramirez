package com.mycompany.hacienda;

import javax.swing.JOptionPane;

public class Hacienda {
public double Total ;
    public static void main(String[] args) {

        String Nombre = JOptionPane.showInputDialog("Digite su nombre");
        int NumCursos = Integer.parseInt(JOptionPane.showInputDialog("Digite la cantidad de cursos que imparte"));
        
        
        for (int i = 0; i == NumCursos; i++) {

            double MontoCurso = Double.parseDouble(JOptionPane.showInputDialog("Digite el monto del curso"));
            double Pago = MontoCurso*2/100;
            double Total =  Total + Pago;       

        }
                System.out.println("El total a pagar de "+Nombre + "a Hacienda es de "+Total);

    }
}
